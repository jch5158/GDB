var searchData=
[
  ['read_5frequest',['read_request',['../structtacopie_1_1tcp__client_1_1read__request.html',1,'tacopie::tcp_client']]],
  ['read_5fresult',['read_result',['../structtacopie_1_1tcp__client_1_1read__result.html',1,'tacopie::tcp_client']]]
];
