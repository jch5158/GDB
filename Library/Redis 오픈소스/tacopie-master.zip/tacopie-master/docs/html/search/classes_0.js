var searchData=
[
  ['io_5fservice',['io_service',['../classtacopie_1_1io__service.html',1,'tacopie']]]
];
