var searchData=
[
  ['error',['error',['../classtacopie_1_1logger__iface.html#a18f9c02fc19be4b9900ac9fb1a361624',1,'tacopie::logger_iface::error()'],['../classtacopie_1_1logger.html#a3fe1be02ac2f4e4fe44a0bdaf8359546',1,'tacopie::logger::error()']]],
  ['event_5fcallback_5ft',['event_callback_t',['../classtacopie_1_1io__service.html#abb66850c32d9c724f4418d77bd04bcfd',1,'tacopie::io_service']]]
];
