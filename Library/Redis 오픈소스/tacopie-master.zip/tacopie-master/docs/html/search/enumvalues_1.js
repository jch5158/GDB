var searchData=
[
  ['debug',['debug',['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efeaad42f6697b035b7580e4fef93be20b4d',1,'tacopie::logger']]]
];
