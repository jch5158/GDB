var searchData=
[
  ['debug',['debug',['../classcpp__redis_1_1logger.html#a9493594d547e7abe71b8690be1946c7aaad42f6697b035b7580e4fef93be20b4d',1,'cpp_redis::logger']]],
  ['dropped',['dropped',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daa41d368a58ee26891a6a586ddaaa604f8',1,'cpp_redis::client::dropped()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338a41d368a58ee26891a6a586ddaaa604f8',1,'cpp_redis::subscriber::dropped()']]]
];
