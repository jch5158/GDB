var searchData=
[
  ['xinfo_5fconsumers',['xinfo_consumers',['../classcpp__redis_1_1client.html#a972e59c216b86e38a1b77a4ca0bc6785',1,'cpp_redis::client::xinfo_consumers(const std::string &amp;key, const std::string &amp;group_name, const reply_callback_t &amp;reply_callback)'],['../classcpp__redis_1_1client.html#a6497165de42557c953189305a0f22542',1,'cpp_redis::client::xinfo_consumers(const std::string &amp;key, const std::string &amp;group_name)']]],
  ['xinfo_5fgroups',['xinfo_groups',['../classcpp__redis_1_1client.html#a99175a1ba56a05cc75c531860aaf5442',1,'cpp_redis::client::xinfo_groups(const std::string &amp;key, const reply_callback_t &amp;reply_callback)'],['../classcpp__redis_1_1client.html#a7c8b502b2d339556f208c36513c94723',1,'cpp_redis::client::xinfo_groups(const std::string &amp;key)']]],
  ['xlen',['xlen',['../classcpp__redis_1_1client.html#a31bd2e133d34097af085e3e024c14a0f',1,'cpp_redis::client::xlen(const std::string &amp;key, const reply_callback_t &amp;reply_callback)'],['../classcpp__redis_1_1client.html#a688bed690967583c3aa6a7d72c8c03f9',1,'cpp_redis::client::xlen(const std::string &amp;key)']]]
];
