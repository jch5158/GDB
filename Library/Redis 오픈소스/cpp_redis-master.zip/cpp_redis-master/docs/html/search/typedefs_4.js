var searchData=
[
  ['sentinel_5fdisconnect_5fhandler_5ft',['sentinel_disconnect_handler_t',['../classcpp__redis_1_1sentinel.html#a923e06b5b700c16dffec8a01d2fa9aa4',1,'cpp_redis::sentinel']]],
  ['subscribe_5fcallback_5ft',['read_callback_t',['../classcpp__redis_1_1subscriber.html#a2ac29261280f488dab483866ae875656',1,'cpp_redis::subscriber']]]
];
