var searchData=
[
  ['buffer',['buffer',['../structcpp__redis_1_1network_1_1tcp__client__iface_1_1read__result.html#af8275097ebe558e7ce0f2aa29131cb05',1,'cpp_redis::network::tcp_client_iface::read_result::buffer()'],['../structcpp__redis_1_1network_1_1tcp__client__iface_1_1write__request.html#ad3567dac827f550b60491af530f0db2e',1,'cpp_redis::network::tcp_client_iface::write_request::buffer()']]]
];
