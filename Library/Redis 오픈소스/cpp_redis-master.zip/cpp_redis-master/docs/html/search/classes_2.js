var searchData=
[
  ['client',['client',['../classcpp__redis_1_1client.html',1,'cpp_redis']]]
];
