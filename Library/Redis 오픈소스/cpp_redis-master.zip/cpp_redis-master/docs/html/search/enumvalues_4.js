var searchData=
[
  ['failed',['failed',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daa26934eb377001f66e37289a5c93fe284',1,'cpp_redis::client::failed()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338a26934eb377001f66e37289a5c93fe284',1,'cpp_redis::subscriber::failed()']]]
];
