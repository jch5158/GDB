var searchData=
[
  ['tcp_5fclient',['tcp_client',['../classcpp__redis_1_1network_1_1tcp__client.html',1,'cpp_redis::network']]],
  ['tcp_5fclient_5fiface',['tcp_client_iface',['../classcpp__redis_1_1network_1_1tcp__client__iface.html',1,'cpp_redis::network']]]
];
