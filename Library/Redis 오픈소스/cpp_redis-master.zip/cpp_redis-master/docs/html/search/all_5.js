var searchData=
[
  ['front',['front',['../structcpp__redis_1_1helpers_1_1front.html',1,'cpp_redis::helpers']]]
];
