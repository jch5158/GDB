var searchData=
[
  ['connect_5fcallback_5ft',['connect_callback_t',['../classcpp__redis_1_1client.html#a8e8f308847caf0b9ce06b817253c65c7',1,'cpp_redis::client::connect_callback_t()'],['../classcpp__redis_1_1subscriber.html#a7f9e56873e5b96ad9cb2395dadae1a7a',1,'cpp_redis::subscriber::connect_callback_t()']]]
];
