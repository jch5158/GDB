var searchData=
[
  ['pubsub',['pubsub',['../classcpp__redis_1_1client.html#a388877b01b4e045cddb138e70a68e000a040f8e6525bd0c62798afb41e6644f37',1,'cpp_redis::client']]]
];
