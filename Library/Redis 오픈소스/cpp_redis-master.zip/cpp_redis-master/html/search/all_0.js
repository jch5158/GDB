var searchData=
[
  ['changelog',['Changelog',['../md_CHANGELOG.html',1,'']]],
  ['contributing',['Contributing',['../md_CONTRIBUTING.html',1,'']]]
];
